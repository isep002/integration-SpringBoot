package sn.edu.isepdiamniadio.dbe.integrationspringboot;

public class LoginRequest {
    private String voterId;
    private String password;

    public String getVoterId() {
        return voterId;
    }

    public void setVoterId(String voterId) {
        this.voterId = voterId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
